# ヘルスチェックエンドポイント詳細設計書

## 1. アーキテクチャ設計

### 1.1 システム構成

```
┌─────────────────────────────────────────────────┐
│                  外部クライアント                  │
│  (K8s, CI/CD, 監視ツール, ロードバランサー)        │
└───────────────────┬─────────────────────────────┘
                    │ HTTP GET /health
                    ▼
┌─────────────────────────────────────────────────┐
│              HTTPサーバー (Express)               │
│  ┌─────────────────────────────────────────┐   │
│  │   Router Middleware                      │   │
│  │   - /health → HealthCheckHandler        │   │
│  └──────────────────┬──────────────────────┘   │
└─────────────────────┼─────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────┐
│          HealthCheckHandler                     │
│  - getHealthStatus()                            │
│  - buildHealthResponse()                        │
└──────────────────┬──────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────┐
│         HealthStatusService                     │
│  - getCurrentStatus()                           │
│  - getVersion()                                 │
│  - getUptime()                                  │
└─────────────────────────────────────────────────┘
```

### 1.2 レイヤー構成

| レイヤー | 責務 | ファイル |
|---------|------|---------|
| **ルーティング層** | HTTPリクエストのルーティング | `src/routes/health.ts` |
| **ハンドラー層** | リクエスト処理、レスポンス生成 | `src/handlers/health-check-handler.ts` |
| **サービス層** | ビジネスロジック、ステータス取得 | `src/services/health-status-service.ts` |
| **型定義層** | TypeScript型定義 | `src/types/health.ts` |

---

## 2. インターフェース設計

### 2.1 ルーティング定義

**ファイル**: `src/routes/health.ts`

```typescript
import express from 'express';
import { HealthCheckHandler } from '../handlers/health-check-handler';

const router = express.Router();
const healthCheckHandler = new HealthCheckHandler();

/**
 * GET /health
 * ヘルスチェックエンドポイント
 */
router.get('/health', healthCheckHandler.getHealthStatus.bind(healthCheckHandler));

export { router as healthRouter };
```

### 2.2 ハンドラー設計

**ファイル**: `src/handlers/health-check-handler.ts`

```typescript
import { Request, Response } from 'express';
import { HealthStatusService } from '../services/health-status-service';
import { HealthResponse } from '../types/health';

/**
 * ヘルスチェックリクエストを処理するハンドラー
 */
export class HealthCheckHandler {
  private healthStatusService: HealthStatusService;

  constructor() {
    this.healthStatusService = new HealthStatusService();
  }

  /**
   * ヘルスステータスを返す
   * @param req - Expressリクエストオブジェクト
   * @param res - Expressレスポンスオブジェクト
   */
  public async getHealthStatus(req: Request, res: Response): Promise<void> {
    try {
      const healthResponse: HealthResponse = await this.buildHealthResponse();
      res.status(200).json(healthResponse);
    } catch (error) {
      // エラーハンドリング（後述）
      this.handleError(error, res);
    }
  }

  /**
   * ヘルスレスポンスを構築
   * @returns ヘルスレスポンスオブジェクト
   */
  private async buildHealthResponse(): Promise<HealthResponse> {
    const status = await this.healthStatusService.getCurrentStatus();
    const version = this.healthStatusService.getVersion();
    const uptime = this.healthStatusService.getUptime();
    const timestamp = new Date().toISOString();

    return {
      status,
      timestamp,
      version,
      uptime,
    };
  }

  /**
   * エラーハンドリング
   * @param error - エラーオブジェクト
   * @param res - Expressレスポンスオブジェクト
   */
  private handleError(error: unknown, res: Response): void {
    console.error('Health check error:', error);

    // 内部エラーでも200を返す（ヘルスチェックの性質上、プロセスが生きていれば正常）
    res.status(200).json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      version: this.healthStatusService.getVersion(),
      uptime: this.healthStatusService.getUptime(),
    });
  }
}
```

### 2.3 サービス層設計

**ファイル**: `src/services/health-status-service.ts`

```typescript
import { readFileSync } from 'fs';
import { join } from 'path';
import { HealthStatus } from '../types/health';

/**
 * ヘルスステータス情報を提供するサービス
 */
export class HealthStatusService {
  private version: string;
  private startTime: number;

  constructor() {
    this.version = this.loadVersion();
    this.startTime = Date.now();
  }

  /**
   * 現在のヘルスステータスを取得
   * @returns ヘルスステータス
   */
  public async getCurrentStatus(): Promise<HealthStatus> {
    // 初期実装では常に "healthy" を返す
    // 将来的には依存サービスチェックを追加
    return 'healthy';
  }

  /**
   * アプリケーションバージョンを取得
   * @returns バージョン文字列
   */
  public getVersion(): string {
    return this.version;
  }

  /**
   * プロセスの稼働時間を秒単位で取得
   * @returns 稼働時間（秒）
   */
  public getUptime(): number {
    return Math.floor((Date.now() - this.startTime) / 1000);
  }

  /**
   * package.jsonからバージョンを読み込む
   * @returns バージョン文字列
   * @private
   */
  private loadVersion(): string {
    try {
      const packageJsonPath = join(process.cwd(), 'package.json');
      const packageJson = JSON.parse(readFileSync(packageJsonPath, 'utf-8'));
      return packageJson.version || 'unknown';
    } catch (error) {
      console.error('Failed to load version from package.json:', error);
      return 'unknown';
    }
  }
}
```

---

## 3. データモデル設計

### 3.1 型定義

**ファイル**: `src/types/health.ts`

```typescript
/**
 * ヘルスステータス
 */
export type HealthStatus = 'healthy' | 'unhealthy';

/**
 * ヘルスチェックレスポンス
 */
export interface HealthResponse {
  /**
   * ヘルスステータス
   */
  status: HealthStatus;

  /**
   * レスポンス生成時刻（ISO 8601形式）
   */
  timestamp: string;

  /**
   * アプリケーションバージョン
   */
  version: string;

  /**
   * プロセスの稼働時間（秒）
   */
  uptime: number;

  /**
   * エラー情報（異常時のみ）
   */
  errors?: HealthError[];
}

/**
 * ヘルスエラー情報（将来の拡張用）
 */
export interface HealthError {
  /**
   * エラーが発生したコンポーネント
   */
  component: string;

  /**
   * エラーメッセージ
   */
  message: string;

  /**
   * エラーコード（オプション）
   */
  code?: string;
}
```

### 3.2 レスポンス例

#### 正常時
```json
{
  "status": "healthy",
  "timestamp": "2025-11-17T05:30:00.000Z",
  "version": "0.0.9",
  "uptime": 86400
}
```

#### 将来の拡張（依存サービス異常時）
```json
{
  "status": "unhealthy",
  "timestamp": "2025-11-17T05:30:00.000Z",
  "version": "0.0.9",
  "uptime": 86400,
  "errors": [
    {
      "component": "database",
      "message": "Connection timeout",
      "code": "DB_TIMEOUT"
    }
  ]
}
```

---

## 4. エラー処理設計

### 4.1 エラー処理方針

| エラーケース | HTTPステータス | レスポンス | 理由 |
|-------------|---------------|-----------|------|
| 正常動作 | 200 OK | 正常レスポンス | アプリケーション稼働中 |
| package.json読み込み失敗 | 200 OK | version: "unknown" | プロセスは稼働中のため |
| 予期しない例外 | 200 OK | 正常レスポンス | プロセスは稼働中のため |

**設計原則**:
- ヘルスチェックエンドポイントは「プロセスが生きているか」を返すため、応答できる限り200 OKを返す
- 内部エラーが発生しても、ベストエフォートで情報を返す
- 将来的に依存サービスチェックを追加した際は、503 Service Unavailableを使用する

### 4.2 エラーログ

- すべてのエラーは `console.error` でログ出力
- スタックトレースはログに含めるが、レスポンスには含めない（セキュリティ）
- ログフォーマット: `"Health check error: [エラーメッセージ]"`

---

## 5. シーケンス図

### 5.1 正常系フロー

```
クライアント        HTTPサーバー      Handler           Service
    |                  |                |                 |
    |-- GET /health -->|                |                 |
    |                  |-- route ------>|                 |
    |                  |                |-- getCurrentStatus() ->|
    |                  |                |<-- "healthy" --|
    |                  |                |-- getVersion() ->|
    |                  |                |<-- "0.0.9" -----|
    |                  |                |-- getUptime() -->|
    |                  |                |<-- 86400 -------|
    |                  |                |                 |
    |                  |                |-- buildResponse()
    |                  |<-- 200 OK -----|                 |
    |<-- JSON ---------|                |                 |
    |                  |                |                 |
```

### 5.2 エラーハンドリングフロー

```
クライアント        HTTPサーバー      Handler           Service
    |                  |                |                 |
    |-- GET /health -->|                |                 |
    |                  |-- route ------>|                 |
    |                  |                |-- getCurrentStatus() ->|
    |                  |                |<-- Error -------|
    |                  |                |                 |
    |                  |                |-- handleError() |
    |                  |                |   (log error)   |
    |                  |                |   (build fallback response)
    |                  |<-- 200 OK -----|                 |
    |<-- JSON ---------|                |                 |
    |                  |                |                 |
```

---

## 6. セキュリティ設計

### 6.1 情報漏洩対策

**禁止事項**:
- 環境変数の内容を返さない
- 内部IPアドレス、ホスト名を返さない
- ファイルパス、ディレクトリ構造を返さない
- スタックトレースを返さない

**許可される情報**:
- アプリケーションバージョン（公開情報）
- 稼働時間（攻撃に利用不可）
- タイムスタンプ（公開情報）

### 6.2 DoS対策

- 処理時間を最小化（目標: 10ms以内）
- 外部依存を持たない（DB、API呼び出しなし）
- メモリ確保を最小化（静的レスポンス生成）

### 6.3 認証・認可

- **認証なし**: 監視ツールからのアクセスを考慮
- **将来の検討**:
  - APIキーベースの認証（オプション）
  - IP制限（オプション）

---

## 7. パフォーマンス設計

### 7.1 パフォーマンス目標

| メトリクス | 目標値 | 測定方法 |
|----------|--------|---------|
| レスポンスタイム (p95) | < 100ms | 統合テストで測定 |
| レスポンスタイム (p99) | < 200ms | 統合テストで測定 |
| スループット | > 1000 req/sec | 負荷テストで測定 |
| CPU使用率 | < 1% | プロファイリングで測定 |
| メモリ使用量 | < 1MB | プロファイリングで測定 |

### 7.2 最適化手法

1. **非同期処理の最小化**
   - `getCurrentStatus()` のみ async（将来の拡張性のため）
   - その他の処理は同期的に実行

2. **キャッシュ戦略**
   - バージョン情報: コンストラクタで1回のみ読み込み
   - 起動時刻: インスタンス変数として保持
   - uptime: リクエスト時に計算（軽量な処理）

3. **不要な処理の排除**
   - ログ出力は最小限
   - JSON.stringify は Express が自動実行

---

## 8. テスト設計

### 8.1 ユニットテスト

**ファイル**: `src/__tests__/services/health-status-service.test.ts`

```typescript
describe('HealthStatusService', () => {
  let service: HealthStatusService;

  beforeEach(() => {
    service = new HealthStatusService();
  });

  describe('getCurrentStatus', () => {
    it('should return "healthy"', async () => {
      const status = await service.getCurrentStatus();
      expect(status).toBe('healthy');
    });
  });

  describe('getVersion', () => {
    it('should return version from package.json', () => {
      const version = service.getVersion();
      expect(version).toMatch(/^\d+\.\d+\.\d+$/);
    });

    it('should return "unknown" if package.json is not found', () => {
      // Mock fs.readFileSync to throw error
      // ...
    });
  });

  describe('getUptime', () => {
    it('should return uptime in seconds', async () => {
      await new Promise(resolve => setTimeout(resolve, 1000));
      const uptime = service.getUptime();
      expect(uptime).toBeGreaterThanOrEqual(1);
    });
  });
});
```

**ファイル**: `src/__tests__/handlers/health-check-handler.test.ts`

```typescript
describe('HealthCheckHandler', () => {
  let handler: HealthCheckHandler;
  let mockRequest: Partial<Request>;
  let mockResponse: Partial<Response>;

  beforeEach(() => {
    handler = new HealthCheckHandler();
    mockRequest = {};
    mockResponse = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn(),
    };
  });

  describe('getHealthStatus', () => {
    it('should return 200 OK with health response', async () => {
      await handler.getHealthStatus(
        mockRequest as Request,
        mockResponse as Response
      );

      expect(mockResponse.status).toHaveBeenCalledWith(200);
      expect(mockResponse.json).toHaveBeenCalledWith(
        expect.objectContaining({
          status: 'healthy',
          timestamp: expect.any(String),
          version: expect.any(String),
          uptime: expect.any(Number),
        })
      );
    });

    it('should handle errors gracefully', async () => {
      // Mock service to throw error
      // ...
    });
  });
});
```

### 8.2 統合テスト

**ファイル**: `src/__tests__/integration/health-endpoint.test.ts`

```typescript
import request from 'supertest';
import { app } from '../../app';

describe('GET /health', () => {
  it('should return 200 OK', async () => {
    const response = await request(app).get('/health');
    expect(response.status).toBe(200);
  });

  it('should return valid JSON', async () => {
    const response = await request(app).get('/health');
    expect(response.headers['content-type']).toMatch(/application\/json/);
  });

  it('should return correct schema', async () => {
    const response = await request(app).get('/health');
    expect(response.body).toMatchObject({
      status: 'healthy',
      timestamp: expect.stringMatching(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/),
      version: expect.stringMatching(/^\d+\.\d+\.\d+$/),
      uptime: expect.any(Number),
    });
  });

  it('should respond within 100ms', async () => {
    const start = Date.now();
    await request(app).get('/health');
    const duration = Date.now() - start;
    expect(duration).toBeLessThan(100);
  });
});
```

### 8.3 E2Eテスト

```bash
# curl での動作確認
curl -X GET http://localhost:3000/health

# 期待されるレスポンス
# HTTP/1.1 200 OK
# Content-Type: application/json
# {
#   "status": "healthy",
#   "timestamp": "2025-11-17T05:30:00.000Z",
#   "version": "0.0.9",
#   "uptime": 86400
# }
```

---

## 9. デプロイ設計

### 9.1 環境別設定

| 環境 | エンドポイント | 備考 |
|-----|--------------|------|
| ローカル | http://localhost:3000/health | 開発用 |
| ステージング | https://stg-api.michi.example/health | 検証用 |
| 本番 | https://api.michi.example/health | 本番用 |

### 9.2 監視設定例（Kubernetes）

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: michi-api
spec:
  containers:
  - name: michi
    image: michi:latest
    livenessProbe:
      httpGet:
        path: /health
        port: 3000
      initialDelaySeconds: 10
      periodSeconds: 30
      timeoutSeconds: 5
      failureThreshold: 3
    readinessProbe:
      httpGet:
        path: /health
        port: 3000
      initialDelaySeconds: 5
      periodSeconds: 10
      timeoutSeconds: 3
      failureThreshold: 2
```

---

## 10. 将来の拡張設計

### 10.1 依存サービスチェック（Phase 2）

```typescript
interface DependencyCheck {
  name: string;
  status: 'healthy' | 'unhealthy';
  responseTime?: number;
  error?: string;
}

interface ExtendedHealthResponse extends HealthResponse {
  dependencies?: DependencyCheck[];
}
```

### 10.2 詳細メトリクス（Phase 3）

```typescript
interface HealthMetrics {
  memory: {
    used: number;
    total: number;
    percentage: number;
  };
  cpu: {
    percentage: number;
  };
  activeRequests: number;
}
```

---

## 11. チェックリスト

### 設計レビュー観点
- [ ] アーキテクチャは拡張可能か
- [ ] セキュリティ要件を満たしているか
- [ ] パフォーマンス目標を達成できるか
- [ ] テスト戦略は適切か
- [ ] エラーハンドリングは十分か
- [ ] ドキュメントは完備されているか

### 実装前の確認事項
- [ ] 既存のHTTPサーバー実装を確認
- [ ] Expressが既にインストールされているか確認
- [ ] ルーティング設定の競合がないか確認
- [ ] テストフレームワークの設定確認

---

**作成日**: 2025-11-17
**承認者**: 未定
**ステータス**: レビュー待ち
