# Gemini CLI, Codex CLI, Cline 仕様調査結果

**調査日**: 2025-11-22
**目的**: Issue #41 - Michiへの追加環境対応のための仕様調査

---

## 1. Gemini CLI

### ディレクトリ構造

- **グローバルコンテキスト**: `~/.gemini/GEMINI.md`
- **ユーザー設定**: `~/.gemini/settings.json`
- **プロジェクト設定**: `<project>/.gemini/settings.json`
- **拡張**: `<workspace>/.gemini/extensions/` または `~/.gemini/extensions/`
- **シェル履歴**: `~/.gemini/tmp/<project_hash>/shell_history`

### 階層的ロードルール

GEMINI.mdファイルは複数箇所から結合され、より具体的なファイルが一般的なものを上書き：

1. **グローバルコンテキスト**: `~/.gemini/GEMINI.md`
2. **プロジェクト/祖先コンテキスト**: 現在のディレクトリからプロジェクトルートまで検索
3. **サブディレクトリコンテキスト**: サブディレクトリも検索（コンポーネント固有の指示用）

### 主要コマンド

- `/init` - 現在のディレクトリを分析してカスタマイズされたGEMINI.mdを生成
- `/directory add` - ワークスペースにディレクトリを追加
- `/memory show` - モデルに送信される最終的な結合コンテキストを表示
- `/settings` - 設定変更用のUI（settings.json編集と同等）

### ファイル形式

- Markdown (`.md`)

### Michiテンプレート設計

```
templates/gemini/
├── GEMINI.md               # プロジェクトコンテキスト（Michi Core Principles相当）
└── extensions/             # 拡張（オプション）
    └── README.md
```

**ENV_CONFIG案**:
```typescript
'gemini': {
  rulesDir: '.gemini',
  commandsDir: '.gemini/extensions',
  templateSource: 'gemini'
}
```

---

## 2. Codex CLI

### ディレクトリ構造

- **設定ディレクトリ**: `~/.codex/`
- **設定ファイル**: `~/.codex/config.toml` (CLI + VSCode拡張で共有)
- **認証ファイル**: `~/.codex/auth.json`

### 設定モデルの特徴

- **共有設定**: CLI と VSCode 拡張が単一の `config.toml` を共有
- **設定形式**: TOML形式
- **上書き**: コマンドライン引数 `-c key=value` で一時的に上書き可能
- **設定内容**: デフォルトモデル、承認ポリシー、サンドボックス設定、MCPサーバー設定

### ルール/コマンドシステム

Codexは設定ファイル中心のアーキテクチャで、Claude/Cursor/Gemini/Clineのような「ルールファイル」や「コマンドディレクトリ」の概念が**ない**。

### Michiテンプレート設計（制限あり）

Codexの仕様上、Michiの「ルール配置」機能との相性が悪い。代替案：

```
templates/codex/
└── README.md               # Codex + Michi統合ガイド
```

**ENV_CONFIG案**:
```typescript
'codex': {
  rulesDir: '.codex/docs',          // ドキュメント配置（非標準）
  commandsDir: '.codex/docs',
  templateSource: 'codex'
}
```

**注意**: Codexは標準的なルールディレクトリをサポートしないため、このテンプレートは限定的。

---

## 3. Cline

### ディレクトリ構造

- **プロジェクトルール（単一ファイル）**: `<project>/.clinerules`
- **プロジェクトルール（ディレクトリ）**: `<project>/.clinerules/` または `<project>/.roo/`
- **プロジェクトルール（推奨）**: `.clinerules/rules/` または `.roo/rules/`
- **中央ルールバンク**: `~/.cline-rules/` (テンプレート保管用)

### ルール管理

- **ファイル形式**: Markdown (`.md`) またはテキスト (`.clinerules`)
- **トグル機能**: v3.13以降、個別ルールファイルの有効/無効切り替え可能
- **複数ルール**: ディレクトリベースで複数のルールファイルを整理可能

### Michiテンプレート設計

```
templates/cline/
└── rules/
    ├── michi-core.md               # Michi Core Principles
    └── atlassian-integration.md    # Atlassian統合ルール
```

**ENV_CONFIG案**:
```typescript
'cline': {
  rulesDir: '.clinerules/rules',
  commandsDir: '.clinerules/commands',  // Michiの拡張（Cline標準ではない）
  templateSource: 'cline'
}
```

---

## 4. 環境間の比較

| 環境 | ルールディレクトリ | コマンドシステム | ファイル形式 | 階層的ロード |
|------|------------------|----------------|-------------|-------------|
| **Claude** | `.claude/rules/` | `.claude/commands/` | Markdown | ❌ |
| **Cursor** | `.cursor/rules/` | `.cursor/commands/` | Markdown | ❌ |
| **Claude Agent** | `.claude/subagents/` | `.claude/commands/` | Markdown | ❌ |
| **Gemini** | `.gemini/` | `.gemini/extensions/` | Markdown | ✅ (GEMINI.md) |
| **Codex** | ❌ (非対応) | ❌ (非対応) | TOML (設定のみ) | ❌ |
| **Cline** | `.clinerules/rules/` | ❌ (標準なし) | Markdown | ❌ |

---

## 5. 実装上の推奨事項

### Gemini対応
- ✅ **フル対応可能** - ルールディレクトリの概念があり、Michiとの相性良好
- `GEMINI.md`をメインコンテキストファイルとして使用
- 階層的ロードを活用可能

### Codex対応
- ⚠️ **制限付き対応** - ルールディレクトリの概念がない
- ドキュメント配置のみ（`.codex/docs/`）
- 実用性が限定的なため、優先度を下げることを推奨

### Cline対応
- ✅ **フル対応可能** - ルールディレクトリをサポート
- `.clinerules/rules/`を使用
- Michiのコマンド機能は非標準だが、拡張として提供可能

---

## 6. 次のステップ

1. **Gemini**: フルテンプレート作成（`GEMINI.md` + extensions）
2. **Cline**: フルテンプレート作成（`.clinerules/rules/`）
3. **Codex**: 簡易テンプレート作成（README.mdのみ、将来的に改善検討）

---

**参考資料**:
- Gemini CLI: https://geminicli.com/docs/get-started/configuration/
- Codex CLI: https://developers.openai.com/codex/local-config/
- Cline: https://github.com/cline/cline/wiki
