# Michi vs cc-sdd: 機能的な差異

## 概要

**Michi**は、**cc-sdd**をベースに、企業の開発フロー全体を自動化するための統合プラットフォームです。

- **cc-sdd**: AI-DLC（AI Driven Development Lifecycle）のコアフレームワーク
- **Michi**: cc-sdd + 企業向け統合機能（Confluence/JIRA、マルチプロジェクト、自動化）

## アーキテクチャの関係

```
cc-sdd (コアフレームワーク)
    ↓ ベースとして使用
Michi (統合プラットフォーム)
    ├── cc-sddの全機能を継承
    └── 企業向け統合機能を追加
```

## 機能比較表

| 機能カテゴリ | cc-sdd | Michi | 説明 |
|------------|--------|------|------|
| **AI-DLCフレームワーク** | ✅ | ✅ | Spec-Driven Developmentのコア機能 |
| **スラッシュコマンド** | ✅ | ✅ | `/kiro:*` コマンド（11コマンド） |
| **テンプレートカスタマイズ** | ✅ | ✅ | `.kiro/settings/templates/` |
| **Steering（プロジェクトメモリ）** | ✅ | ✅ | `.kiro/steering/` |
| **品質ゲート** | ✅ | ✅ | `validate-gap`, `validate-design` |
| **Confluence統合** | ❌ | ✅ | REST API経由で自動同期 |
| **JIRA統合** | ❌ | ✅ | Epic/Story自動作成・更新 |
| **マルチプロジェクト対応** | ❌ | ✅ | `.kiro/project.json`で管理 |
| **GitHub SSoT** | ⚠️ | ✅ | GitHubを真実の源として明示的に管理 |
| **フェーズバリデーション** | ❌ | ✅ | `validate:phase` コマンド |
| **フェーズ自動実行** | ❌ | ✅ | `phase:run` コマンド |
| **CLIツール** | ❌ | ✅ | `michi` コマンド（NPMパッケージ） |
| **プロジェクト横断操作** | ❌ | ✅ | `project:list`, `project:dashboard` |
| **見積もり集計** | ❌ | ✅ | `multi-estimate` コマンド |
| **PR自動化** | ❌ | ✅ | `pr-automation.ts` |
| **ワークフロー承認ゲート** | ❌ | ✅ | `.env`で承認者ロール設定 |
| **プロジェクトセットアップ自動化** | ❌ | ✅ | `create-project`, `setup-existing` |

## 詳細な機能差異

### 1. Confluence/JIRA統合

#### cc-sdd
- **なし**: cc-sddはAI-DLCフレームワークのコアのみを提供
- 仕様書（requirements.md, design.md, tasks.md）はローカルの`.kiro/specs/`に保存

#### Michi
- **REST API統合**: Confluence/JIRAへの自動同期機能
- **Markdown↔Confluence変換**: 仕様書をConfluenceページとして公開
- **JIRA Epic/Story自動作成**: tasks.mdからJIRAチケットを自動生成
- **ラベル管理**: プロジェクト横断でラベルで分類・検索
- **階層構造**: Confluenceページの親子関係を自動管理

**実装**:
- `scripts/confluence-sync.ts`: Confluenceページ作成・更新
- `scripts/jira-sync.ts`: JIRA Epic/Story作成・更新
- `scripts/markdown-to-confluence.ts`: Markdown→Confluence変換

**使用例**:
```bash
# Confluenceに要件定義を同期
npx @michi/cli confluence:sync user-auth requirements

# JIRAにタスクを作成
npx @michi/cli jira:sync user-auth
```

### 2. マルチプロジェクト対応

#### cc-sdd
- **単一プロジェクト**: 1つのリポジトリで1つのプロジェクトを管理
- プロジェクト識別機能なし

#### Michi
- **マルチプロジェクト**: 3-5プロジェクトを同時並行で管理
- **プロジェクトメタデータ**: `.kiro/project.json`でプロジェクトを識別
- **プロジェクト横断操作**: 全プロジェクトの一覧・集計・ダッシュボード

**プロジェクトメタデータ例**:
```json
{
  "projectId": "customer-a-service-1",
  "projectName": "A社 サービス1",
  "jiraProjectKey": "PRJA",
  "confluenceLabels": ["project:customer-a-service-1", "service:s1"]
}
```

**使用例**:
```bash
# 全プロジェクト一覧
npx @michi/cli project:list

# プロジェクト横断ダッシュボード生成
npx @michi/cli project:dashboard

# 見積もり集計（全プロジェクト）
npm run multi-estimate
```

### 3. GitHub SSoT（Single Source of Truth）

#### cc-sdd
- **ローカル管理**: 仕様書は`.kiro/specs/`に保存
- GitHubへの同期は手動（Git操作）

#### Michi
- **GitHub SSoT**: GitHubを真実の源として明示的に管理
- **Confluenceは参照のみ**: Confluenceは承認者向けの参照用
- **自動同期**: フェーズ完了時に自動でConfluence/JIRAに同期

**アーキテクチャ**:
```
GitHub (.kiro/specs/) ← 情報源（SSoT）
    ↓ 自動同期
Confluence ← ドキュメント管理（参照のみ）
JIRA ← タスク管理・進捗追跡
```

### 4. フェーズバリデーション

#### cc-sdd
- **なし**: フェーズ完了の自動チェック機能なし

#### Michi
- **フェーズバリデーション**: 各フェーズの完了を自動チェック
- **抜け漏れ防止**: Confluence/JIRA作成の抜け漏れを検出

**使用例**:
```bash
# 要件定義フェーズのバリデーション
npx @michi/cli validate:phase user-auth requirements

# 設計フェーズのバリデーション
npx @michi/cli validate:phase user-auth design

# タスク分割フェーズのバリデーション
npx @michi/cli validate:phase user-auth tasks
```

**バリデーション項目**:
- requirements.md作成済み
- Confluenceページ作成済み
- spec.jsonに記録済み
- 前提条件（前フェーズ完了）の確認

### 5. フェーズ自動実行

#### cc-sdd
- **なし**: AIコマンドのみ（手動でConfluence/JIRA作成が必要）

#### Michi
- **フェーズ自動実行**: AIコマンド + スクリプト実行で抜け漏れ防止
- **一括処理**: フェーズ完了時にConfluence/JIRA作成を自動実行

**使用例**:
```bash
# 要件定義フェーズ（AI + 自動化）
/kiro:spec-requirements user-auth
npx @michi/cli phase:run user-auth requirements

# 設計フェーズ（AI + 自動化）
/kiro:spec-design user-auth
npx @michi/cli phase:run user-auth design

# タスク分割フェーズ（AI + 自動化）
/kiro:spec-tasks user-auth
npx @michi/cli phase:run user-auth tasks
```

**実行内容**:
1. Markdownファイル存在確認
2. Confluence/JIRA作成・更新
3. spec.json自動更新
4. バリデーション実行

### 6. CLIツール

#### cc-sdd
- **なし**: スラッシュコマンドのみ（IDE内で実行）

#### Michi
- **CLIツール**: `michi`コマンド（NPMパッケージ）
- **コマンドライン実行**: ターミナルから直接実行可能
- **CI/CD統合**: スクリプトとしてCI/CDパイプラインに組み込み可能

**インストール**:
```bash
# グローバルインストール
npm install -g @sk8metal/michi-cli

# または、npxで実行（推奨）
npx @sk8metal/michi-cli --help
```

**主要コマンド**:
- `michi phase:run <feature> <phase>`: フェーズ実行
- `michi validate:phase <feature> <phase>`: バリデーション
- `michi confluence:sync <feature> [type]`: Confluence同期
- `michi jira:sync <feature>`: JIRA連携
- `michi project:list`: プロジェクト一覧
- `michi project:dashboard`: ダッシュボード生成

### 7. プロジェクト横断操作

#### cc-sdd
- **なし**: 単一プロジェクトのみ

#### Michi
- **プロジェクト一覧**: 全プロジェクトの情報を一覧表示
- **リソースダッシュボード**: Confluenceにプロジェクト横断ダッシュボードを作成
- **見積もり集計**: 全プロジェクトの見積もりをExcelに集計

**使用例**:
```bash
# 全プロジェクト一覧
npx @michi/cli project:list

# リソースダッシュボード生成
npx @michi/cli project:dashboard

# 見積もり集計
npm run multi-estimate
```

### 8. ワークフロー承認ゲート

#### cc-sdd
- **なし**: 承認ゲート機能なし

#### Michi
- **承認ゲート設定**: `.env`で承認者ロールを設定
- **フェーズ別承認**: 要件定義、設計、リリースで異なる承認者を設定可能

**設定例**:
```bash
# .env
APPROVAL_GATES_REQUIREMENTS=projectLeader,director
APPROVAL_GATES_DESIGN=architect,director
APPROVAL_GATES_RELEASE=serviceManager,director
```

### 9. プロジェクトセットアップ自動化

#### cc-sdd
- **手動セットアップ**: `npx cc-sdd@latest`でテンプレート作成のみ

#### Michi
- **新規プロジェクト作成**: `create-project`コマンドで一括セットアップ
- **既存プロジェクト追加**: `setup-existing`スクリプトで既存リポジトリに追加
- **対話式セットアップ**: プロジェクト名、JIRAキーを対話式で入力

**使用例**:
```bash
# 新規プロジェクト作成
npm run create-project -- \
  --name "customer-a-service-1" \
  --project-name "A社 サービス1" \
  --jira-key "PRJA"

# 既存プロジェクトに追加
bash /path/to/michi/scripts/setup-existing.sh
```

### 10. PR自動化

#### cc-sdd
- **なし**: PR作成機能なし

#### Michi
- **PR自動化**: `pr-automation.ts`でGitHub PRを自動作成
- **JIRA連携**: PR作成時にJIRAチケットを自動更新

**実装**:
- `scripts/pr-automation.ts`: GitHub PR作成・更新

## コマンド比較

### cc-sddのコマンド（Michiでも使用可能）

| コマンド | 説明 |
|---------|------|
| `/kiro:spec-init <description>` | 仕様初期化 |
| `/kiro:spec-requirements <feature>` | 要件定義生成 |
| `/kiro:spec-design <feature>` | 設計生成 |
| `/kiro:spec-tasks <feature>` | タスク分割 |
| `/kiro:spec-impl <feature> <tasks>` | TDD実装 |
| `/kiro:spec-status <feature>` | 進捗確認 |
| `/kiro:steering` | Steering作成/更新 |
| `/kiro:steering-custom` | カスタムSteering作成 |
| `/kiro:validate-gap <feature>` | 既存機能との差異分析 |
| `/kiro:validate-design <feature>` | 設計統合検証 |

### Michiが追加したコマンド

| コマンド | 説明 | 実行場所 |
|---------|------|---------|
| `/kiro:confluence-sync <feature> [type]` | Confluence同期 | Cursor内 |
| `/kiro:project-switch <project_id>` | プロジェクト切り替え | Cursor内 |
| `michi phase:run <feature> <phase>` | フェーズ実行 | CLI |
| `michi validate:phase <feature> <phase>` | フェーズバリデーション | CLI |
| `michi confluence:sync <feature> [type]` | Confluence同期 | CLI |
| `michi jira:sync <feature>` | JIRA連携 | CLI |
| `michi project:list` | プロジェクト一覧 | CLI |
| `michi project:dashboard` | ダッシュボード生成 | CLI |
| `michi workflow:run --feature <name>` | 統合ワークフロー実行 | CLI |
| `michi preflight [phase]` | プリフライトチェック | CLI |

## 依存関係

### cc-sdd
- **軽量**: テンプレートとコマンド定義のみ
- **依存パッケージ**: なし（NPMパッケージとして配布）

### Michi
- **cc-sdd必須**: cc-sddをベースとして使用
- **追加依存パッケージ**:
  - `@octokit/rest`: GitHub REST API
  - `axios`: HTTPクライアント
  - `jira-client`: JIRA REST API
  - `markdown-it`: Markdownパーサー
  - `turndown`: HTML→Markdown変換
  - `exceljs`: Excelファイル生成
  - `zod`: スキーマバリデーション

## 使用シナリオ

### cc-sddが適している場合

- ✅ **個人開発**: 1人の開発者が1つのプロジェクトを管理
- ✅ **小規模チーム**: 3-5人のチームで1つのプロジェクト
- ✅ **プロトタイプ開発**: 迅速なプロトタイピング
- ✅ **学習・実験**: AI-DLCの学習・実験

### Michiが適している場合

- ✅ **企業開発**: 承認フローが必要な企業環境
- ✅ **マルチプロジェクト**: 3-5プロジェクトを同時並行で管理
- ✅ **Confluence/JIRA必須**: 既存のAtlassian環境と統合が必要
- ✅ **CI/CD統合**: 自動化スクリプトをCI/CDに組み込みたい
- ✅ **プロジェクト横断管理**: 複数プロジェクトの進捗を一元管理したい

## まとめ

### cc-sdd
- **コアフレームワーク**: AI-DLCの基本機能を提供
- **軽量**: テンプレートとコマンド定義のみ
- **汎用的**: あらゆるAIエージェント（Claude, Cursor, Gemini等）で使用可能

### Michi
- **統合プラットフォーム**: cc-sdd + 企業向け統合機能
- **企業向け**: Confluence/JIRA統合、マルチプロジェクト、承認ゲート
- **自動化重視**: フェーズ自動実行、バリデーション、CI/CD統合

### 関係性

```
cc-sdd（コアフレームワーク）
    ↓ ベースとして使用
Michi（統合プラットフォーム）
    ├── cc-sddの全機能を継承
    └── 企業向け統合機能を追加
```

**結論**: Michiはcc-sddの**スーパーセット**です。cc-sddの全機能を使用しつつ、企業向けの統合機能を追加したプラットフォームです。

