# テスト仕様書・実行テンプレート統合計画

## 背景

現在、テスト関連ファイルが分散している：

| 場所 | 目的 | 問題点 |
|------|------|--------|
| `docs/user-guide/templates/test-specs/` | テスト仕様書テンプレート | test-spec-generatorで使用されるが、実行テンプレートと分離 |
| `templates/testing/` | テスト実行テンプレート | test-interactive.tsで使用されるが、phase:runと未連携 |
| `.kiro/specs/<feature>/test-specs/` | 生成されたテスト仕様書 | 実行ファイルが生成されない |

## 目標

1. `michi phase:run <feature> test-type-selection` でテストタイプを選択
2. `michi phase:run <feature> test-spec` で選択されたテストの**仕様書**を生成（設計段階）
3. `michi phase:run <feature> phase-b` で選択されたテストの**実行ファイル**を生成（リリース準備）
4. test-interactive.tsをphase-bと連携

## 設計

### 1. 統合テンプレート構造

```
templates/
├── test-specs/              # 既存を移動（仕様書テンプレート）
│   ├── unit-test-spec-template.md
│   ├── integration-test-spec-template.md
│   ├── e2e-test-spec-template.md
│   ├── performance-test-spec-template.md
│   └── security-test-spec-template.md
│
└── test-execution/          # 新規作成（実行テンプレート）
    ├── unit/
    │   ├── vitest.config.ts.template
    │   └── sample-test.ts.template
    ├── integration/
    │   └── integration-test.md.template
    ├── e2e/
    │   └── e2e-test.md.template
    ├── performance/
    │   ├── locustfile.py.template
    │   └── load-test-plan.md.template
    └── security/
        ├── zap-config.yaml.template
        ├── run-zap-scan.sh.template
        └── security-test-plan.md.template
```

### 2. 生成される出力構造

```
.kiro/specs/<feature>/
├── test-type-selection.json    # テストタイプ選択結果
├── test-specs/                 # テスト仕様書
│   ├── unit-test-spec.md
│   ├── integration-test-spec.md
│   └── ...
└── test-execution/             # テスト実行ファイル（新規）
    ├── unit/
    │   └── vitest.config.ts
    ├── performance/
    │   └── locustfile.py
    └── security/
        ├── zap-config.yaml
        └── run-zap-scan.sh
```

### 3. 修正対象ファイル

#### 3.1 test-spec-generator.ts の拡張

```typescript
// 新規追加: テスト実行ファイル生成
export async function generateTestExecution(
  feature: string,
  testType: string,
  projectRoot: string = process.cwd()
): Promise<void> {
  // test-interactive.tsのロジックを統合
  // テストタイプに応じた実行ファイルを生成
}

// 既存関数の拡張
export async function generateTestSpec(
  feature: string,
  testType: string,
  projectRoot: string = process.cwd(),
  options: { generateExecution?: boolean } = {}
): Promise<void> {
  // 既存: テスト仕様書生成
  // 新規: options.generateExecution が true なら実行ファイルも生成
}
```

#### 3.2 phase-runner.ts の修正（runTestSpecPhase関数）

```typescript
// 既存のコードに追加
for (const testType of testTypes) {
  // 既存: テスト仕様書生成
  await generateTestSpec(feature, testType);

  // 新規: テスト実行ファイル生成
  await generateTestExecution(feature, testType);
}
```

#### 3.3 test-interactive.ts の修正

- スタンドアロン実行モード（現状）を維持
- phase:runから呼び出せるAPI関数をエクスポート
- テンプレートパスを`templates/test-execution/`に変更

### 4. テストタイプと生成ファイルのマッピング

| テストタイプ | 仕様書 | 実行ファイル |
|-------------|--------|--------------|
| unit | unit-test-spec.md | vitest.config.ts, sample-test.ts |
| integration | integration-test-spec.md | integration-test.md（手動チェックリスト） |
| e2e | e2e-test-spec.md | e2e-test.md（手動チェックリスト） |
| performance | performance-test-spec.md | locustfile.py, load-test-plan.md |
| security | security-test-spec.md | zap-config.yaml, run-zap-scan.sh |

### 5. 実装手順

1. **Step 1**: `templates/test-execution/` ディレクトリ作成
   - 既存の`templates/testing/`をリネーム・移動
   - テストタイプごとにサブディレクトリ作成

2. **Step 2**: `test-spec-generator.ts` に `generateTestExecution()` 追加
   - test-interactive.tsからロジックを移植
   - テストタイプ別の実行ファイル生成

3. **Step 3**: `phase-runner.ts` の `runTestSpecPhase()` 修正
   - 仕様書と実行ファイルの両方を生成

4. **Step 4**: `test-interactive.ts` をリファクタリング
   - スタンドアロンモードとAPIモードの両対応
   - 共通関数をエクスポート

5. **Step 5**: ドキュメント更新
   - workflow.md
   - quick-start.md
   - test-planning-flow.md

## 確認事項

1. 既存のtest-type-selection.jsonフォーマットは変更するか？
   - 現状維持を推奨

2. performance/securityの実行ファイルは対話的に生成するか？
   - 推奨: 基本パラメータはdesign.md/requirements.mdから自動抽出
   - 詳細パラメータはデフォルト値を使用（後から編集可能）

3. 単体テストの実行ファイルは言語別に分けるか？
   - 推奨: spec.jsonのenvironmentSetup.languageから言語を判定
   - Node.js → vitest, Java → JUnit, Python → pytest

## 次のステップ

ユーザー確認後、上記Step 1から実装開始
