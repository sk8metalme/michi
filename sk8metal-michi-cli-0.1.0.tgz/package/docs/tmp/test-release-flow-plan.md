# Michiテスト・リリースフロー整備計画

**最終更新**: 2025-11-21
**ステータス**: Phase 3実施中（ドキュメント作成フェーズ）

---

## 1. プロジェクト概要

Michiプロジェクトに不足している以下のフローを整備する：
1. テスト計画フロー（Phase -1 ～ Phase 0-5）
2. テスト実施フロー（Phase A/B）
3. リリース準備フロー

---

## 2. 確定した設計方針

### 2.1 要件定義（Q1-Q6の回答）

| 質問 | 回答 | 詳細 |
|------|------|------|
| Q1. CI/CD自動実行範囲 | **C** | 単体テスト + ビルド + Lint |
| Q2. 手動テスト実行タイミング | **C** | タグ作成前（リリース準備として実行） |
| Q3. GitHub Release | **B** | 手動作成（タグ作成後） |
| Q4. リリースノート | **B** | 手動作成 |
| Q5. ビルド成果物 | **B** | 手動で生成（ローカル） |
| Q6. Phase A/B | **C** | Phase A: PR前に単体テスト<br>Phase B: リリース前に単体テスト以外の全テスト |

### 2.2 対応範囲

- **CI/CDツール**: GitHub ActionsとScrewdriverのみ
- **対応言語**: Node.js、Java、PHPのみ
- **対象外**: パッケージpublish/deployはmichiの対象外

### 2.3 テスト実行方式

| テストタイプ | 実行方式 | タイミング |
|------------|---------|----------|
| 単体テスト | **CI/CD自動実行** | PR時 & タグ作成時 |
| 統合テスト | **手動実行** | タグ作成前（Phase B） |
| E2Eテスト | **手動実行** | タグ作成前（Phase B） |
| パフォーマンステスト | **手動実行** | タグ作成前（Phase B、必要に応じて） |
| セキュリティテスト | **手動実行** | タグ作成前（Phase B、必要に応じて） |

### 2.4 CI/CD構成（簡素化版）

#### CI/CDで自動実行
- Lint（言語別）
- 単体テスト（言語別）
- ビルド（言語別）

#### 手動実行
- 統合テスト、E2E、パフォーマンス、セキュリティテスト
- GitHub Release作成
- リリースノート作成
- ビルド成果物の生成・添付

---

## 3. 確定したドキュメント構成

### 3.1 最終ディレクトリ構造

```
docs/
├── michi-development/               # michiプロジェクト自体の開発
│   ├── testing-strategy.md          # ✅ 既存を移動
│   └── contributing/                # ✅ 既存を移動
│       ├── release.md
│       └── development.md
│
└── user-guide/                      # michi利用者向け（すべて）
    ├── getting-started/             # ✅ 既存を移動
    ├── guides/                      # ✅ 既存を移動
    ├── hands-on/                    # ✅ 既存を移動
    ├── reference/                   # ✅ 既存を移動
    │
    ├── templates/                   # ✅ 既存を移動 + 新規追加
    │   ├── claude-agent/            # 既存
    │   ├── test-specs/              # 🔲 新規
    │   │   ├── README.md                            # ✅ 完成
    │   │   ├── unit-test-spec-template.md           # 🔲 作成待ち
    │   │   ├── integration-test-spec-template.md    # 🔲 作成待ち
    │   │   ├── e2e-test-spec-template.md            # 🔲 作成待ち
    │   │   ├── performance-test-spec-template.md    # 🔲 作成待ち
    │   │   └── security-test-spec-template.md       # 🔲 作成待ち
    │   └── cicd/                    # 🔲 新規
    │       ├── github-actions/
    │       │   ├── nodejs.yml       # 🔲 作成待ち
    │       │   ├── java.yml         # 🔲 作成待ち
    │       │   └── php.yml          # 🔲 作成待ち
    │       └── screwdriver/
    │           ├── nodejs.yaml      # 🔲 作成待ち
    │           ├── java.yaml        # 🔲 作成待ち
    │           └── php.yaml         # 🔲 作成待ち
    │
    ├── testing-strategy.md          # 🔲 新規: 利用者プロジェクトのテスト戦略
    │
    ├── testing/                     # 🔲 新規: テスト詳細ガイド
    │   ├── integration-tests.md     # ✅ 既存を移動
    │   ├── test-planning-flow.md    # 🔲 作成待ち
    │   ├── tdd-cycle.md             # 🔲 作成待ち
    │   ├── test-execution-flow.md   # 🔲 作成待ち
    │   └── test-failure-handling.md # 🔲 作成待ち
    │
    └── release/                     # 🔲 新規: リリース関連ガイド
        ├── release-flow.md          # 🔲 作成待ち
        └── ci-setup.md              # 🔲 作成待ち
```

凡例:
- ✅ 完了
- 🔲 作成待ち

---

## 4. 完了した作業（Phase 1-2）

### Phase 1: ファイル移動（完了）

```bash
# michi開発関連を michi-development/ へ移動
✅ docs/testing-strategy.md → docs/michi-development/
✅ docs/contributing/release.md → docs/michi-development/contributing/
✅ docs/contributing/development.md → docs/michi-development/contributing/

# 利用者向けを user-guide/ へ移動
✅ docs/getting-started → docs/user-guide/
✅ docs/guides → docs/user-guide/
✅ docs/hands-on → docs/user-guide/
✅ docs/reference → docs/user-guide/
✅ templates → docs/user-guide/templates/
✅ docs/testing/integration-tests.md → docs/user-guide/testing/
```

### Phase 2: 新規ディレクトリ作成（完了）

```bash
✅ docs/user-guide/testing/
✅ docs/user-guide/release/
✅ docs/user-guide/templates/test-specs/
✅ docs/user-guide/templates/cicd/github-actions/
✅ docs/user-guide/templates/cicd/screwdriver/
```

### Phase 3: ドキュメント作成（進行中）

```bash
✅ docs/user-guide/templates/test-specs/README.md
```

---

## 5. 残りの作業（Phase 3続き）

### 5.1 テスト仕様書テンプレート（5ファイル）

以下のテンプレートを作成する。各テンプレートの内容は「6. 設計済みドキュメント内容」セクションを参照。

#### 優先度: 高

1. **unit-test-spec-template.md** - 単体テスト仕様書
2. **integration-test-spec-template.md** - 統合テスト仕様書
3. **e2e-test-spec-template.md** - E2Eテスト仕様書

#### 優先度: 中

4. **performance-test-spec-template.md** - パフォーマンステスト仕様書
5. **security-test-spec-template.md** - セキュリティテスト仕様書

### 5.2 テスト関連ドキュメント（4ファイル）

#### 優先度: 高

1. **docs/user-guide/testing/test-planning-flow.md**
   - Phase -1: テストタイプ選択
   - Phase 0-1 ～ Phase 0-5: テスト計画からタスク化まで

2. **docs/user-guide/testing/tdd-cycle.md**
   - RED-GREEN-REFACTORサイクル
   - 重要原則: テストは仕様、実装に合わせて修正しない

3. **docs/user-guide/testing/test-execution-flow.md**
   - Phase A: PR前に単体テスト（CI/CD自動）
   - Phase B: リリース前に単体テスト以外（手動）

#### 優先度: 中

4. **docs/user-guide/testing/test-failure-handling.md**
   - テスト失敗の分類
   - 対応フローチャート

### 5.3 テスト戦略ドキュメント（1ファイル）

#### 優先度: 高

1. **docs/user-guide/testing-strategy.md**
   - michi利用者向けのテスト戦略
   - Phase A/Bの概要
   - 各ドキュメントへの参照

### 5.4 リリース関連ドキュメント（2ファイル）

#### 優先度: 高

1. **docs/user-guide/release/release-flow.md**
   - 確定したリリース準備フロー
   - Phase A → PR → Phase B → タグ作成 → CI/CD → GitHub Release

2. **docs/user-guide/release/ci-setup.md**
   - GitHub ActionsとScrewdriverの設定ガイド
   - 言語別（Node.js、Java、PHP）の設定例

### 5.5 CI/CD設定テンプレート（6ファイル）

#### 優先度: 中

GitHub Actions用（3ファイル）:
1. **docs/user-guide/templates/cicd/github-actions/nodejs.yml**
2. **docs/user-guide/templates/cicd/github-actions/java.yml**
3. **docs/user-guide/templates/cicd/github-actions/php.yml**

Screwdriver用（3ファイル）:
4. **docs/user-guide/templates/cicd/screwdriver/nodejs.yaml**
5. **docs/user-guide/templates/cicd/screwdriver/java.yaml**
6. **docs/user-guide/templates/cicd/screwdriver/php.yaml**

---

## 6. 設計済みドキュメント内容

### 6.1 テスト仕様書テンプレート共通構造

すべてのテスト仕様書テンプレートは以下の構造を持つ：

```markdown
# {{TEST_TYPE}} Test Specification: {{TEST_NAME}}

**Author**: {{AUTHOR}}
**Date**: {{DATE}}
**Version**: 1.0

## 1. Overview

### 1.1 Purpose
[テストの目的]

### 1.2 Scope
[テスト範囲]

### 1.3 Testing Tool
- **Tool**: {{TOOL_NAME}}
- **Version**: {{VERSION}}

## 2. Test Environment

### 2.1 Software Requirements
[必要なソフトウェア]

### 2.2 Hardware Requirements
[必要なハードウェア、該当する場合]

### 2.3 Test Data
[テストデータの準備]

## 3. Test Cases

### Test Case {{ID}}: {{TEST_CASE_NAME}}

**Description**: [テストケースの説明]

**Preconditions**:
[前提条件]

**Test Steps**:
1. [ステップ1]
2. [ステップ2]
3. [ステップ3]

**Expected Results**:
[期待される結果]

**Actual Results**:
[実行時に記入]

**Status**: [ ] Pass / [ ] Fail / [ ] Blocked

**Notes**:
[追加メモ]

---

## 4. Test Execution Summary

| ID | Test Name | Status | Executed By | Date | Notes |
|----|-----------|--------|-------------|------|-------|
| {{ID}} | {{NAME}} | | | | |

## 5. Defects Found

| Defect ID | Severity | Description | Status |
|-----------|----------|-------------|--------|
| | | | |

## 6. Sign-off

**Tested By**: _______________
**Date**: _______________
**Approved By**: _______________
**Date**: _______________
```

### 6.2 テスト仕様書の種類別の特徴

#### Unit Test Template
- **追加セクション**: "3.1 Functions/Classes to Test", "3.2 Mocking Strategy"
- **Test Case ID形式**: `UT-001`, `UT-002`, ...

#### Integration Test Template
- **追加セクション**: "3.1 Integration Points", "3.2 External Dependencies"
- **Test Case ID形式**: `IT-001`, `IT-002`, ...

#### E2E Test Template
- **追加セクション**: "3.1 User Flows", "3.2 Browser/Device Matrix"
- **Test Case ID形式**: `E2E-001`, `E2E-002`, ...

#### Performance Test Template
- **追加セクション**: "3.1 Performance Metrics", "3.2 Load Scenarios", "3.3 Acceptance Criteria"
- **Test Case ID形式**: `PT-001`, `PT-002`, ...
- **メトリクス例**: Response Time, Throughput, Resource Usage

#### Security Test Template
- **追加セクション**: "3.1 Security Requirements", "3.2 Threat Model", "3.3 Vulnerability Checklist"
- **Test Case ID形式**: `ST-001`, `ST-002`, ...
- **チェック項目**: Authentication, Authorization, Input Validation, Data Encryption

---

## 7. リリース準備フロー（確定版）

```
[開発完了]
    ↓
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Phase A: PR前の確認（自動）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    ├─ 単体テスト実行（CI/CD）
    ├─ Lint実行（CI/CD）
    ├─ ビルド実行（CI/CD）
    └─ ✅ すべて成功 → PR作成可能
    ↓
[PR作成・レビュー・マージ]
    ↓
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Phase B: リリース準備（手動）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    ├─ 統合テスト実行（手動）
    ├─ E2Eテスト実行（手動）
    ├─ パフォーマンステスト実行（手動、必要に応じて）
    ├─ セキュリティテスト実行（手動、必要に応じて）
    └─ ✅ すべて成功 → タグ作成
    ↓
[タグ作成（手動）]
    ↓
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CI/CD実行（自動）
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    ├─ 単体テスト実行（CI/CD）
    ├─ Lint実行（CI/CD）
    ├─ ビルド実行（CI/CD）
    └─ ✅ すべて成功 → CI/CD完了
    ↓
[GitHub Release作成（手動）]
    ├─ リリースノート作成（手動）
    ├─ ビルド成果物生成（ローカル、手動）
    └─ GitHub Releaseに添付
    ↓
[リリース完了]
※ パッケージpublish/deployはmichiの対象外
```

---

## 8. 言語別CI/CD設定

### Node.js / TypeScript
```yaml
# GitHub Actions
- Lint: npm run lint (ESLint)
- Test: npm test (Vitest)
- Build: npm run build (tsc)

# Screwdriver
- Lint: npm run lint
- Test: npm test
- Build: npm run build
```

### Java
```yaml
# GitHub Actions
- Lint: mvn checkstyle:check
- Test: mvn test (JUnit 5)
- Build: mvn package

# Screwdriver
- Lint: mvn checkstyle:check
- Test: mvn test
- Build: mvn package
```

### PHP
```yaml
# GitHub Actions
- Lint: composer phpstan (PHPStan)
- Test: composer test (PHPUnit)
- Build: composer install --no-dev

# Screwdriver
- Lint: composer phpstan
- Test: composer test
- Build: composer install --no-dev
```

---

## 9. 次のセッションでの作業手順

### ステップ1: 現在の状態を確認

```bash
# ディレクトリ構造を確認
tree docs -L 3 -d

# 既存ファイルを確認
ls -la docs/user-guide/templates/test-specs/
```

### ステップ2: 優先度の高いドキュメントから作成

**推奨順序**:

1. **テスト仕様書テンプレート（優先度: 高）**
   ```bash
   # 以下のファイルを作成
   docs/user-guide/templates/test-specs/unit-test-spec-template.md
   docs/user-guide/templates/test-specs/integration-test-spec-template.md
   docs/user-guide/templates/test-specs/e2e-test-spec-template.md
   ```
   - **内容**: セクション6.1と6.2の設計に従う
   - **プレースホルダー**: `{{...}}` 形式を使用

2. **テスト関連ドキュメント（優先度: 高）**
   ```bash
   docs/user-guide/testing/test-planning-flow.md
   docs/user-guide/testing/tdd-cycle.md
   docs/user-guide/testing/test-execution-flow.md
   ```
   - **test-planning-flow.md**: Phase -1からPhase 0-5まで
   - **tdd-cycle.md**: RED-GREEN-REFACTORサイクル + 重要原則
   - **test-execution-flow.md**: Phase A/B詳細

3. **テスト戦略ドキュメント（優先度: 高）**
   ```bash
   docs/user-guide/testing-strategy.md
   ```
   - **内容**: michi利用者向けの総合テスト戦略
   - **参照**: 作成したテストドキュメントへのリンク

4. **リリース関連ドキュメント（優先度: 高）**
   ```bash
   docs/user-guide/release/release-flow.md
   docs/user-guide/release/ci-setup.md
   ```
   - **release-flow.md**: セクション7のフローを記述
   - **ci-setup.md**: セクション8の言語別設定を記述

5. **テスト仕様書テンプレート（優先度: 中）**
   ```bash
   docs/user-guide/templates/test-specs/performance-test-spec-template.md
   docs/user-guide/templates/test-specs/security-test-spec-template.md
   ```

6. **テスト失敗時対応（優先度: 中）**
   ```bash
   docs/user-guide/testing/test-failure-handling.md
   ```

7. **CI/CD設定テンプレート（優先度: 中）**
   ```bash
   docs/user-guide/templates/cicd/github-actions/*.yml
   docs/user-guide/templates/cicd/screwdriver/*.yaml
   ```

### ステップ3: 各ドキュメント作成時のチェックリスト

- [ ] セクション構造が設計に従っているか
- [ ] プレースホルダー（`{{...}}`）が適切に使用されているか
- [ ] 他のドキュメントへのリンクが正しいか
- [ ] 言語が英語か（テンプレート）/ 日本語か（ガイドドキュメント）
- [ ] コード例が適切に記述されているか（該当する場合）

### ステップ4: 完了後の確認

```bash
# すべてのファイルが作成されたか確認
find docs/user-guide -type f -name "*.md" | sort

# GitステータスでNew filesを確認
jj status
```

### ステップ5: コミットとPR作成

```bash
# コミット
jj commit -m "docs: Add test planning, test execution, and release flow documentation

- Add 5 test specification templates (unit, integration, e2e, performance, security)
- Add test planning flow (Phase -1 to Phase 0-5)
- Add TDD cycle documentation
- Add test execution flow (Phase A/B)
- Add release flow and CI/CD setup guides
- Reorganize docs into michi-development/ and user-guide/

🤖 Generated with Claude Code

Co-Authored-By: Claude <noreply@anthropic.com>"

# ブックマーク作成
jj bookmark create docs/test-release-flow -r '@-'

# プッシュ
jj git push --bookmark docs/test-release-flow --allow-new

# PR作成
gh pr create --head docs/test-release-flow --base main \
  --title "docs: Add test planning, test execution, and release flow documentation" \
  --body "テスト計画、テスト実施、リリースフローのドキュメントを追加しました。

## 変更内容

### 新規ドキュメント
- テスト仕様書テンプレート（5種類）
- テスト計画フロー（Phase -1～Phase 0-5）
- TDDサイクル
- テスト実施フロー（Phase A/B）
- リリースフロー
- CI/CD設定ガイド

### ドキュメント構成変更
- \`docs/michi-development/\`: michiプロジェクト自体の開発ドキュメント
- \`docs/user-guide/\`: michi利用者向けドキュメント（すべて）

## テスト方針

### Phase A（PR前）
- CI/CDで自動実行: 単体テスト + Lint + ビルド

### Phase B（リリース前）
- 手動実行: 統合テスト + E2E + パフォーマンス + セキュリティ

## CI/CD

- 対応ツール: GitHub Actions、Screwdriver
- 対応言語: Node.js、Java、PHP

🤖 Generated with Claude Code"
```

---

## 10. 重要な注意事項

### 10.1 テスト修正の原則

**絶対に守るべきルール**: テストは仕様を表すため、実装に合わせてテストを修正してはならない。

- ❌ NG: 実装がテストと合わないからテストを修正
- ✅ OK: 仕様が変更されたのでテストを修正

### 10.2 過去のテストの扱い

**オプションA（採用済み）**: 過去のテストも回帰テストとして継続実行

- ディレクトリが存在すれば自動実行
- 不要なテストディレクトリは手動削除

### 10.3 パッケージpublish/deployについて

**michiの対象外**: リリースフローはGitHub Release作成まで。その後のnpm publish、Docker push、RPMパッケージ作成等は利用者が別途実装。

---

## 11. 完了基準

以下のすべてが完了した時点でこのプロジェクトは完了：

- [ ] すべてのテスト仕様書テンプレートが作成された（5ファイル）
- [ ] すべてのテスト関連ドキュメントが作成された（4ファイル）
- [ ] テスト戦略ドキュメントが作成された（1ファイル）
- [ ] すべてのリリース関連ドキュメントが作成された（2ファイル）
- [ ] すべてのCI/CD設定テンプレートが作成された（6ファイル）
- [ ] ドキュメント間のリンクが正しく設定されている
- [ ] PRが作成され、レビュー済みである
- [ ] mainブランチにマージされている

---

**次のセッションで作業を開始する際は、このドキュメントの「9. 次のセッションでの作業手順」に従ってください。**
