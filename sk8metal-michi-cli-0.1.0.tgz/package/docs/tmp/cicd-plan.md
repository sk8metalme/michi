# CI/CD整備計画書

## 1. 現状分析

### 1.1 プロジェクト概要

- **プロジェクト名**: Michi (道)
- **パッケージ名**: `@sk8metal/michi-cli`
- **バージョン**: 0.0.2
- **リポジトリ**: https://github.com/sk8metalme/michi
- **ライセンス**: MIT License

### 1.2 技術スタック

- **言語**: TypeScript 5.3.3
- **ランタイム**: Node.js 20.x以上
- **ビルドツール**: TypeScript Compiler (tsc)
- **テストフレームワーク**: Vitest 1.1.1
- **リント**: ESLint 8.56.0
- **パッケージマネージャー**: npm 10.0.0以上

### 1.3 既存のテスト状況

#### テストファイル
- ✅ `src/__tests__/cli.test.ts` - CLIツールの基本動作テスト
- ✅ `scripts/__tests__/validate-phase.test.ts` - フェーズバリデーションテスト
- ✅ `scripts/utils/__tests__/config-validator.test.ts` - 設定バリデーションテスト
- ✅ `scripts/utils/__tests__/feature-name-validator.test.ts` - 機能名バリデーションテスト

#### テストスクリプト
- `npm test` - Vitest実行（ウォッチモード）
- `npm run test:run` - Vitest実行（1回のみ）
- `npm run test:ui` - Vitest UI実行

### 1.4 ビルド・公開プロセス

#### ビルド
- `npm run build` - TypeScriptコンパイル（`dist/`に出力）
- `npm run prepare` - インストール前の自動ビルド

#### 公開
- NPMパッケージとして公開（`@sk8metal/michi-cli`）
- `package.json`の`files`フィールドで公開ファイルを制御

### 1.5 現状の課題

#### CI/CD未整備
- ❌ GitHub Actionsのワークフローファイルが存在しない
- ❌ プッシュ・PR時の自動テストが未実装
- ❌ 自動ビルド検証が未実装
- ❌ NPMパッケージ公開の自動化が未実装
- ❌ コードカバレッジレポートが未実装
- ❌ セキュリティスキャンが未実装

#### テストカバレッジ
- 現状のテストカバレッジが不明
- カバレッジレポートの生成が未実装

#### リリースプロセス
- 手動でのバージョン更新・CHANGELOG更新
- 手動でのNPMパッケージ公開

## 2. CI/CDの目標

### 2.1 短期目標（Phase 1-2）

1. **自動テスト実行**
   - プッシュ・PR時の自動テスト実行
   - テスト失敗時の通知

2. **ビルド検証**
   - TypeScriptコンパイルの自動検証
   - ビルド成果物の検証

3. **コード品質チェック**
   - ESLintの自動実行
   - TypeScript型チェックの自動実行

4. **セキュリティスキャン**
   - 依存関係の脆弱性スキャン
   - シークレット検出

### 2.2 中期目標（Phase 3-4）

1. **テストカバレッジ**
   - カバレッジレポートの自動生成
   - カバレッジ閾値の設定（目標: 80%以上）

2. **自動リリース**
   - タグ作成時の自動NPMパッケージ公開
   - CHANGELOGの自動更新

3. **マトリックステスト**
   - 複数Node.jsバージョンでのテスト（20.x, 22.x）

### 2.3 長期目標（Phase 5-6）

1. **E2Eテスト**
   - Confluence/JIRA連携のE2Eテスト
   - モックサーバーを使用した統合テスト

2. **パフォーマンステスト**
   - ビルド時間の測定
   - メモリ使用量の監視

3. **ドキュメント自動生成**
   - APIドキュメントの自動生成
   - 変更履歴の自動更新

## 3. 実装計画

### Phase 1: 基本CIパイプライン（優先度: 高）

#### 3.1.1 GitHub Actionsワークフロー作成

**ファイル**: `.github/workflows/ci.yml`

**機能**:
- プッシュ・PR時の自動テスト実行
- TypeScriptコンパイル検証
- ESLint実行
- TypeScript型チェック

**トリガー**:
- `push`（すべてのブランチ）
- `pull_request`（すべてのブランチ）

**ジョブ**:
1. **test**: テスト実行
2. **lint**: ESLint実行
3. **type-check**: TypeScript型チェック
4. **build**: ビルド検証

**所要時間**: 1-2日

#### 3.1.2 セキュリティスキャン

**ファイル**: `.github/workflows/security.yml`

**機能**:
- `npm audit`による脆弱性スキャン
- GitHub Dependabot設定
- シークレット検出

**トリガー**:
- `push`（mainブランチ）
- `schedule`（週1回）

**所要時間**: 0.5日

### Phase 2: テストカバレッジ（優先度: 高）

#### 3.2.1 カバレッジレポート生成

**機能**:
- Vitestのカバレッジレポート生成
- CodecovまたはCoverallsへのアップロード
- PRコメントでのカバレッジ表示

**設定**:
- `vitest.config.ts`にカバレッジ設定を追加
- カバレッジ閾値: 15%（段階的に60%→80%へ引き上げ）

**所要時間**: 1日

#### 3.2.2 カバレッジバッジ

**機能**:
- README.mdにカバレッジバッジを追加
- リアルタイムでのカバレッジ表示

**所要時間**: 0.5日

### Phase 3: 自動リリース（優先度: 中）

#### 3.3.1 NPMパッケージ公開

**ファイル**: `.github/workflows/release.yml`

**機能**:
- タグ作成時の自動NPMパッケージ公開
- バージョン番号の自動検出
- リリースノートの自動生成

**トリガー**:
- `push`（`v*`タグ）

**セキュリティ**:
- NPM_TOKENのシークレット管理
- 公開前のビルド・テスト実行

**所要時間**: 1-2日

#### 3.3.2 CHANGELOG自動更新

**機能**:
- コミットメッセージからCHANGELOG自動生成
- セマンティックバージョニングに基づく分類

**ツール候補**:
- `standard-version`
- `semantic-release`

**所要時間**: 1日

### Phase 4: マトリックステスト（優先度: 中）

#### 3.4.1 複数Node.jsバージョンでのテスト

**機能**:
- Node.js 20.x, 22.xでのテスト実行
- 互換性の確認

**設定**:
- GitHub Actionsの`matrix`戦略を使用

**所要時間**: 0.5日

### Phase 5: E2Eテスト（優先度: 低）

#### 3.5.1 統合テスト環境構築

**機能**:
- Confluence/JIRAモックサーバーの構築
- E2Eテストの実装

**ツール候補**:
- `msw`（Mock Service Worker）
- `nock`（HTTPモック）

**所要時間**: 2-3日

### Phase 6: パフォーマンステスト（優先度: 低）

#### 3.6.1 ビルド時間測定

**機能**:
- ビルド時間の記録
- パフォーマンス回帰の検出

**所要時間**: 1日

## 4. 技術スタック詳細

### 4.1 CI/CDプラットフォーム

**GitHub Actions**（選択理由）
- GitHubリポジトリと統合
- 無料プランで十分な実行時間
- 豊富なアクションエコシステム
- シークレット管理が容易

### 4.2 テストカバレッジツール

**Codecov**（推奨）
- GitHub統合が容易
- PRコメントでのカバレッジ表示
- 無料プランあり

**代替案**: Coveralls

### 4.3 リリース自動化ツール

**semantic-release**（推奨）
- セマンティックバージョニング自動化
- CHANGELOG自動生成
- NPM公開の自動化

**代替案**: standard-version

### 4.4 セキュリティスキャン

**GitHub Dependabot**
- 依存関係の脆弱性スキャン
- 自動プルリクエスト生成
- GitHub統合

**npm audit**
- NPM標準ツール
- CI/CDでの自動実行

## 5. ワークフロー設計

### 5.1 CIワークフロー（`.github/workflows/ci.yml`）

```yaml
name: CI

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main, develop]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - run: npm ci
      - run: npm run test:run
      - run: npm run build

  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - run: npm ci
      - run: npm run lint

  type-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - run: npm ci
      - run: npm run type-check
```

### 5.2 リリースワークフロー（`.github/workflows/release.yml`）

```yaml
name: Release

on:
  push:
    tags:
      - 'v*'

jobs:
  release:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          registry-url: 'https://registry.npmjs.org'
      - run: npm ci
      - run: npm run build
      - run: npm run test:run
      - run: npm publish
        env:
          NODE_AUTH_TOKEN: ${{ secrets.NPM_TOKEN }}
```

### 5.3 セキュリティワークフロー（`.github/workflows/security.yml`）

```yaml
name: Security

on:
  push:
    branches: [main]
  schedule:
    - cron: '0 0 * * 0' # 毎週日曜日

jobs:
  audit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
      - run: npm ci
      - run: npm audit --audit-level=moderate
```

## 6. セキュリティ考慮事項

### 6.1 シークレット管理

**GitHub Secrets**を使用:
- `NPM_TOKEN`: NPMパッケージ公開用トークン
- `CODECOV_TOKEN`: カバレッジレポートアップロード用トークン

**設定方法**:
1. GitHubリポジトリのSettings > Secrets and variables > Actions
2. New repository secretで追加

### 6.2 依存関係のセキュリティ

**Dependabot設定**:
- `.github/dependabot.yml`を作成
- 週1回の自動スキャン
- セキュリティ更新の自動プルリクエスト

### 6.3 コードスキャン

**GitHub Code Scanning**:
- CodeQLの有効化（オプション）
- 静的解析による脆弱性検出

## 7. メトリクス・モニタリング

### 7.1 CI/CDメトリクス

**測定項目**:
- テスト実行時間
- ビルド時間
- CI/CD成功率
- 平均PRマージ時間

**可視化**:
- GitHub Actionsのダッシュボード
- カスタムダッシュボード（オプション）

### 7.2 テストカバレッジメトリクス

**測定項目**:
- 全体カバレッジ率
- ファイル別カバレッジ率
- カバレッジトレンド

**目標値**:
- Phase 1（現在）: 15%以上（CI失敗を防ぐための最小値）
- Phase 2（中期）: 60%以上
- Phase 3（長期）: 80%以上
- Phase 4以降: 90%以上

### 7.3 パフォーマンスメトリクス

**測定項目**:
- ビルド時間
- テスト実行時間
- パッケージサイズ

**目標値**:
- ビルド時間: 30秒以内
- テスト実行時間: 1分以内

## 8. 実装スケジュール

### Week 1: Phase 1（基本CIパイプライン）

- Day 1-2: CIワークフロー作成・テスト
- Day 3: セキュリティスキャン設定
- Day 4-5: 動作確認・ドキュメント更新

### Week 2: Phase 2（テストカバレッジ）

- Day 1: カバレッジ設定・レポート生成
- Day 2: Codecov統合・バッジ追加
- Day 3-5: テストカバレッジ向上（60%→80%）

### Week 3: Phase 3（自動リリース）

- Day 1-2: リリースワークフロー作成
- Day 3: CHANGELOG自動更新設定
- Day 4-5: 動作確認・ドキュメント更新

### Week 4: Phase 4-6（拡張機能）

- Day 1: マトリックステスト設定
- Day 2-3: E2Eテスト環境構築（オプション）
- Day 4-5: パフォーマンステスト設定（オプション）

## 9. 成功基準

### 9.1 Phase 1完了基準

- [x] プッシュ・PR時に自動テストが実行される（`.github/workflows/ci.yml`作成済み）
- [x] ESLint・型チェックが自動実行される（`.github/workflows/ci.yml`作成済み）
- [x] セキュリティスキャンが週1回実行される（`.github/workflows/security.yml`作成済み）
- [x] Dependabot設定（`.github/dependabot.yml`作成済み）
- [ ] テスト失敗時の通知設定（GitHub Actionsのデフォルト通知で対応可能）

### 9.2 Phase 2完了基準

- [x] カバレッジレポートが自動生成される（`vitest.config.ts`作成済み、`npm run test:coverage`追加済み）
- [x] CIワークフローにカバレッジアップロード追加済み（`.github/workflows/ci.yml`）
- [x] READMEにカバレッジバッジが表示される（README.md更新済み）
- [x] Codecovアカウント設定（GitHubリポジトリと連携完了）
- [x] PRコメントにカバレッジが表示される（Codecov設定完了）
- [ ] テストカバレッジが80%以上（現状15%→段階的に60%→80%へ引き上げ予定）

### 9.3 Phase 3完了基準

- [x] リリースワークフロー作成済み（`.github/workflows/release.yml`作成済み）
- [x] NPM_TOKENのシークレット設定（GitHub Secretsに追加完了）
- [x] タグ作成時に自動NPM公開される（v0.0.3で動作確認済み）
- [ ] CHANGELOGが自動更新される（semantic-release導入が必要）
- [ ] リリースノートが自動生成される（semantic-release導入が必要）

## 10. リスクと対策

### 10.1 リスク

1. **CI/CD実行時間の増加**
   - リスク: テスト・ビルド時間が長くなる
   - 対策: 並列実行、キャッシュ活用

2. **セキュリティトークンの漏洩**
   - リスク: NPM_TOKENなどの漏洩
   - 対策: GitHub Secretsの適切な管理、最小権限の原則

3. **テストカバレッジの低下**
   - リスク: 新機能追加時にカバレッジが低下
   - 対策: PR時のカバレッジチェック、閾値設定

### 10.2 対策

- **並列実行**: テスト・リント・型チェックを並列実行
- **キャッシュ**: `node_modules`とビルド成果物をキャッシュ
- **段階的導入**: Phase 1から順次実装、動作確認後に次フェーズへ

## 11. ドキュメント更新

### 11.1 更新が必要なドキュメント

- [ ] `README.md`: CI/CDバッジの追加
- [ ] `docs/setup.md`: CI/CD設定の説明追加
- [ ] `docs/testing.md`: CI/CDでのテスト実行方法追加
- [ ] `CONTRIBUTING.md`: コントリビューションガイドライン追加（新規作成）

### 11.2 新規作成が必要なドキュメント

- [ ] `CONTRIBUTING.md`: コントリビューションガイドライン
- [ ] `.github/CONTRIBUTING.md`: GitHub固有のガイドライン（オプション）

## 12. 次のステップ

### ✅ 完了した作業（Phase 1-2の基本実装）

1. **Phase 1の実装完了**
   - ✅ `.github/workflows/ci.yml`の作成
   - ✅ `.github/workflows/security.yml`の作成
   - ✅ `.github/workflows/release.yml`の作成

2. **Dependabot設定完了**
   - ✅ `.github/dependabot.yml`の作成

3. **Vitestカバレッジ設定完了**
   - ✅ `vitest.config.ts`の作成
   - ✅ `package.json`に`test:coverage`スクリプト追加
   - ✅ `@vitest/coverage-v8`依存関係追加
   - ✅ CIワークフローにカバレッジアップロード追加

4. **README更新**
   - ✅ CI/CDバッジ追加

### ✅ 完了した作業（Phase 2-3完了）

1. **Codecovアカウント設定**（Phase 2完了）
   - ✅ GitHubリポジトリとCodecovを連携
   - ✅ PRコメントにカバレッジが表示される

2. **NPM_TOKEN設定**（Phase 3完了）
   - ✅ 設定ガイド作成済み（`docs/npm-token-setup.md`）
   - ✅ NPMアカウントでAutomation Tokenを生成
   - ✅ GitHub Secretsに`NPM_TOKEN`を追加
   - ✅ リリースワークフローで動作確認済み（v0.0.3でNPM公開成功）

### 🔄 次に実行すべきアクション

1. **テストカバレッジ向上**（Phase 2の継続改善）
   - 現状: 15%（CI失敗を防ぐための最小値）
   - 目標: 段階的に60%→80%へ引き上げ
   - テストファイルの追加・拡充が必要

2. **semantic-release導入**（Phase 3の拡張）
   - `semantic-release`パッケージのインストール
   - リリースワークフローの更新
   - CHANGELOG自動生成の実装

3. **CI/CDの最適化**（Phase 4以降）
   - マトリックステストの拡充
   - E2Eテスト環境構築
   - パフォーマンステスト設定

### 優先順位

1. **最優先**: ✅ Codecov設定・動作確認（Phase 2完了）
2. **高優先度**: ✅ NPM_TOKEN設定・リリーステスト（Phase 3完了）
3. **中優先度**: テストカバレッジ向上（15%→60%→80%）
4. **中優先度**: semantic-release導入（Phase 3拡張）
5. **低優先度**: Phase 4-6（拡張機能）

## 参考リンク

- [GitHub Actions公式ドキュメント](https://docs.github.com/ja/actions)
- [Vitest公式ドキュメント](https://vitest.dev/)
- [Codecov公式ドキュメント](https://docs.codecov.com/)
- [semantic-release公式ドキュメント](https://semantic-release.gitbook.io/)
- [GitHub Dependabot公式ドキュメント](https://docs.github.com/ja/code-security/dependabot)
- [NPM_TOKEN設定ガイド](./npm-token-setup.md) - NPM_TOKEN設定の詳細手順

