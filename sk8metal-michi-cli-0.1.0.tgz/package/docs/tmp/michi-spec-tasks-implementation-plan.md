# Michi 専用 tasks.md 生成コマンド実装計画

## 概要

Kiro の標準 `/kiro:spec-tasks` コマンドとは別に、Michi ワークフロー専用の `/michi:spec-tasks` コマンドを実装する。

## 目的

- Michi バリデーター (`michi validate:phase`) が期待する tasks.md フォーマットを生成
- 日本語曜日表記 `（月）`, `（火）`, `（水）` を含む
- Phase/Story 構造と JIRA 連携メタデータを含む
- Kiro の標準フォーマットを一切変更しない

## 背景

### 現状の問題

1. **Kiro と Michi は異なるツール**
   - Kiro: AI-DLC (AI Development Life Cycle) 標準フォーマット
   - Michi: JIRA 連携を前提とした独自ワークフロー管理ツール

2. **tasks.md フォーマットの違い**
   - **Kiro 形式**: AI-DLC チェックボックス番号方式 (`- [ ] 1.1`, `- [ ] 1.2`)
   - **Michi 形式**: Phase/Story 構造 (`## Phase X.Y:`, `### Story X.Y.Z:`)

3. **曜日表記の違い**
   - **Kiro**: 英語形式 `Day 1 (Mon):`, `Day 2-3 (Tue-Wed):`
   - **Michi**: 日本語形式 `Day 1（月）:`, `Day 2-3（火水）:`

### Michi バリデーターの要件

`/opt/homebrew/lib/node_modules/@sk8metal/michi-cli/dist/scripts/validate-phase.js` (127-135行目):

```javascript
// 曜日表記チェック
if (!tasksContent.includes('（月）') && !tasksContent.includes('（火）')) {
    warnings.push('⚠️  tasks.mdに曜日表記（月、火、水...）が含まれていません');
}

// 営業日カウントチェック
if (!tasksContent.includes('Day 1') && !tasksContent.includes('Day1')) {
    warnings.push('⚠️  tasks.mdに営業日カウント（Day 1, Day 2...）が含まれていません');
}

// 土日休み明記チェック
if (!tasksContent.includes('土日')) {
    warnings.push('⚠️  tasks.mdに土日休みの明記がありません');
}
```

## 実装設計

### ディレクトリ構造

```
プロジェクトルート/
├── .kiro/                         # Kiro 標準（既存・変更なし）
│   ├── commands/
│   │   └── kiro/
│   │       └── kiro-spec-tasks.md # 既存の Kiro コマンド
│   └── settings/
│       └── templates/
│           └── specs/
│               └── tasks.md       # Kiro 標準テンプレート
│
├── .michi/                        # Michi 専用（新規作成）
│   ├── commands/
│   │   └── spec-tasks.md         # /michi:spec-tasks コマンド本体
│   ├── settings/
│   │   ├── templates/
│   │   │   └── specs/
│   │   │       └── tasks.md      # Michi 形式テンプレート
│   │   └── rules/
│   │       └── tasks-generation.md # Michi 固有ルール
│   └── config.json               # Michi 設定（既存）
│
└── .claude/commands/              # Claude Code コマンド登録
    └── michi/
        └── spec-tasks.md         # コマンドエントリーポイント
```

### 実装ステップ

#### ステップ 1: ディレクトリ構造の作成

```bash
mkdir -p .michi/commands
mkdir -p .michi/settings/templates/specs
mkdir -p .michi/settings/rules
mkdir -p .claude/commands/michi
```

#### ステップ 2: Michi 専用テンプレートの作成

**ファイル**: `.michi/settings/templates/specs/tasks.md`

**ベース**: `.kiro/settings/templates/specs/tasks.md` をコピーして以下を修正:

1. **プロジェクト情報セクション** (6-11行目):
   ```markdown
   - **開始予定日**: {{START_DATE}}（曜日）Day 1
   - **完了予定日**: {{END_DATE}}（曜日）
   - **総営業日数**: X営業日（営業日ベース）
   - **総工数見積**: X人日
   - **休日**: 土曜日・日曜日を除外
   - **注意**: このタスク分割は営業日ベースで作成されています（土日・祝日を除外）
   ```

2. **タイムラインセクション** (347-365行目):
   ```markdown
   ### Week 1: 仕様化フェーズ

   Day 1（月）:
     - Story 0.1.1: 要件定義書作成
     - Story 0.2.1: 基本設計開始

   Day 2-3（火水）:
     - Story 0.2.1: 基本設計完了
     - Story 0.3.1: テストタイプ選択（任意）
     - 技術レビュー・PM承認

   Day 4-5（木金）:
     - Story 1.1: テスト環境セットアップ（任意）
     - Story 2.1: プロジェクトセットアップ
   ```

3. **Phase 構造の明確化**:
   - Phase 0.1, 0.2, 2, 4, 5 を必須とする
   - Story ヘッダー (`### Story X.Y.Z:`) を必須とする

#### ステップ 3: Michi 専用ルールファイルの作成

**ファイル**: `.michi/settings/rules/tasks-generation.md`

**ベース**: `.kiro/settings/rules/tasks-generation.md` をコピーして以下を追加:

```markdown
## Michi Workflow Specific Rules

### Phase/Story Structure (Mandatory)

**MUST use Phase headers**:
- `## Phase 0.1: 要件定義（Requirements）`
- `## Phase 0.2: 設計（Design）`
- `## Phase 2: TDD実装（Implementation）`
- `## Phase 4: リリース準備（Release Preparation）`
- `## Phase 5: リリース（Release）`

**MUST use Story headers**:
- `### Story X.Y.Z: Story Title`

**DO NOT use AI-DLC checkbox format**:
- ❌ `- [ ] 1.` (major task numbering)
- ❌ `- [ ] 1.1` (sub-task numbering)
- ✅ Use Story-based structure instead

### Weekday Notation (Mandatory)

**MUST include Japanese weekday notation**:
- Use full-width parentheses: `（月）`, `（火）`, `（水）`, `（木）`, `（金）`
- Example: `Day 1（月）:`
- Example for ranges: `Day 2-3（火水）:`

**MUST include weekend exclusion**:
- `土日休み`
- `土曜日・日曜日を除外`
- `※土日・祝日を除く`

**MUST include business day counting**:
- `Day 1`, `Day 2`, `Day 3`, etc.

### Timeline Section (Mandatory)

**MUST include timeline section** with weekday notation:

```markdown
## タイムライン（営業日ベース）

**前提**: 土日・祝日を除いた営業日で計算

### Week 1: 仕様化フェーズ

Day 1（月）:
  - Story 0.1.1: 要件定義書作成

Day 2-3（火水）:
  - Story 0.2.1: 基本設計完了
```
```

#### ステップ 4: Michi コマンド本体の作成

**ファイル**: `.michi/commands/spec-tasks.md`

```markdown
---
name: /michi:spec-tasks
description: Generate tasks.md in Michi workflow format with Japanese weekday notation
---

# Michi Tasks Generator

**Important**: Generate output in the language specified in `{{KIRO_DIR}}/project.json`.

## Overview

This command generates a detailed task breakdown (`tasks.md`) from the design specification (`design.md`) following the **Michi Workflow Format**.

**Critical Differences from Kiro**:
1. **MUST** use Phase/Story structure (NOT AI-DLC checkbox format)
2. **MUST** include Japanese weekday notation: `（月）`, `（火）`, `（水）`
3. **MUST** include timeline section with weekday notation
4. **MUST** include weekend exclusion: `土日休み`

## Usage

```
/michi:spec-tasks <feature-name> [-y]
```

## Input Files

1. `{{KIRO_DIR}}/specs/{{FEATURE_NAME}}/design.md` - Design specification
2. `{{KIRO_DIR}}/specs/{{FEATURE_NAME}}/requirements.md` - Requirements specification
3. `{{KIRO_DIR}}/project.json` - Project metadata

## Output File

`{{KIRO_DIR}}/specs/{{FEATURE_NAME}}/tasks.md`

## Execution Steps

### Step 1: Load Context

**Read all necessary context**:
- `.kiro/specs/$1/spec.json`, `requirements.md`, `design.md`
- `.kiro/specs/$1/tasks.md` (if exists, for merge mode)
- **Entire `.kiro/steering/` directory** for complete project memory

**Validate approvals**:
- If `-y` flag provided: Auto-approve requirements and design in spec.json
- Otherwise: Verify both approved (stop if not)

### Step 2: Load Michi-Specific Rules and Template

**Load generation rules and template**:
- Read `.michi/settings/rules/tasks-generation.md` for Michi-specific principles
- Read `.michi/settings/templates/specs/tasks.md` for Michi format

### Step 3: Generate Tasks Following Michi Format

**Generate task list following all Michi rules**:
- Use language specified in spec.json
- Use Phase/Story structure (NOT AI-DLC checkbox format)
- Include Japanese weekday notation: `（月）`, `（火）`, `（水）`
- Include timeline section with weekday notation
- Document weekend exclusion: `土日休み`
- Map all requirements to tasks
- Ensure all design components included

### Step 4: Finalize

**Write and update**:
- Create/update `.kiro/specs/$1/tasks.md`
- Update spec.json metadata:
  - Set `phase: "tasks-generated"`
  - Set `approvals.tasks.generated: true, approved: false`
  - Update `updated_at` timestamp

## Validation Checklist

Before finalizing, verify:

- [ ] Phase headers exist (Phase 0.1, 0.2, 2, 4, 5 at minimum)
- [ ] Story headers follow format (`### Story X.Y.Z:`)
- [ ] **Japanese weekday notation is present: `（月）`, `（火）`, `（水）`**
- [ ] **Weekend exclusion is documented: 土日休み**
- [ ] Day numbering is present (Day 1, Day 2, etc.)
- [ ] Timeline section is included with weekday notation
- [ ] NO AI-DLC format (`- [ ] 1.`, `- [ ] 1.1`) is used
- [ ] Effort estimates are included
- [ ] Acceptance criteria use checkboxes `- [ ]`
- [ ] Estimate summary table is included

## Important Notes

1. **DO NOT** use AI-DLC checkbox format (`- [ ] 1.`, `- [ ] 1.1`)
2. **MUST** use Phase headers (`## Phase X.Y:`)
3. **MUST** use Story headers (`### Story X.Y.Z:`)
4. **MUST** include Japanese weekday notation: `（月）`, `（火）`, `（水）`
5. **MUST** document weekend exclusion: 土日休み
6. **MUST** include Timeline section with weekday notation
7. **MUST** include day numbering (Day 1, Day 2, etc.)
```

#### ステップ 5: Claude Code コマンド定義の作成

**ファイル**: `.claude/commands/michi/spec-tasks.md`

```markdown
---
description: Generate tasks.md in Michi workflow format with Japanese weekday notation
allowed-tools: Read, Write, Edit, MultiEdit, Glob, Grep
argument-hint: <feature-name> [-y]
---

# Michi Tasks Generator

<background_information>
- **Mission**: Generate Michi-compliant tasks.md with Phase/Story structure and Japanese weekday notation
- **Success Criteria**:
  - Phase/Story structure (NOT AI-DLC checkbox format)
  - Japanese weekday notation: （月）, （火）, （水）
  - Timeline section with weekday notation
  - Weekend exclusion: 土日休み
</background_information>

<instructions>
## Core Task
Generate Michi-compliant tasks.md for feature **$1**.

## Execution Steps

### Step 1: Delegate to Michi Command

Read and execute `.michi/commands/spec-tasks.md` with the provided feature name and flags.

**Arguments**:
- Feature name: $1
- Auto-approve flag: $2 (if "-y")

### Step 2: Follow Michi Format Rules

Follow all rules defined in:
- `.michi/settings/rules/tasks-generation.md`
- `.michi/settings/templates/specs/tasks.md`

## Critical Constraints

- **MUST use Phase/Story structure** (NOT AI-DLC checkbox format)
- **MUST include Japanese weekday notation**: `（月）`, `（火）`, `（水）`
- **MUST include timeline section** with weekday notation
- **MUST document weekend exclusion**: `土日休み`
</instructions>

## Tool Guidance
- **Read first**: Load Michi-specific rules and templates
- **Write last**: Generate tasks.md only after complete analysis

## Output Description

Provide brief summary in Japanese:

1. **Status**: Confirm tasks generated at `.kiro/specs/$1/tasks.md`
2. **Format Compliance**:
   - ✅ Phase/Story structure used
   - ✅ Japanese weekday notation included
   - ✅ Timeline section included
   - ✅ Weekend exclusion documented
3. **Next Action**: Run `michi validate:phase $1 tasks`
```

## 検証方法

### 1. コマンド実行

```bash
# Michi 形式で tasks.md を生成
/michi:spec-tasks <feature-name>

# 自動承認モード
/michi:spec-tasks <feature-name> -y
```

### 2. Michi バリデーション実行

```bash
michi validate:phase <feature-name> tasks
```

### 3. 期待される結果

- ✅ 曜日表記の警告が解消される
- ✅ Phase/Story 構造が正しく生成される
- ✅ タイムラインセクションが含まれる
- ✅ 土日休みが明記される

## 既存コードへの影響

### 変更なし

- `.kiro/commands/kiro/kiro-spec-tasks.md` - **変更なし**
- `.kiro/settings/templates/specs/tasks.md` - **変更なし**
- `.kiro/settings/rules/tasks-generation.md` - **変更なし**

### 新規作成のみ

- `.michi/` ディレクトリ配下のファイルはすべて新規作成
- 既存の Kiro ワークフローに一切影響なし

## 使い分け

| コマンド | 用途 | フォーマット | JIRA 連携 |
|---------|------|------------|----------|
| `/kiro:spec-tasks` | Kiro 標準ワークフロー | AI-DLC チェックボックス方式 | なし |
| `/michi:spec-tasks` | Michi ワークフロー | Phase/Story 構造 | あり |

## 将来の拡張性

Michi 専用コマンドを追加可能:

- `/michi:spec-requirements` - Michi 形式の要件定義生成
- `/michi:spec-design` - Michi 形式の設計書生成
- `/michi:spec-validate` - Michi バリデーション統合

## 実装優先度

1. **P0（最優先）**: `.michi/settings/templates/specs/tasks.md` - テンプレート作成
2. **P0（最優先）**: `.michi/commands/spec-tasks.md` - コマンド本体作成
3. **P0（最優先）**: `.claude/commands/michi/spec-tasks.md` - Claude Code 統合
4. **P1（次優先）**: `.michi/settings/rules/tasks-generation.md` - ルール詳細化
5. **P2（オプション）**: ドキュメント・使用例の作成

## 参考資料

- Michi バリデーターソースコード: `/opt/homebrew/lib/node_modules/@sk8metal/michi-cli/dist/scripts/validate-phase.js`
- 既存 Kiro テンプレート: `.kiro/settings/templates/specs/tasks.md`
- 既存 Kiro ルール: `.kiro/settings/rules/tasks-generation.md`

---

**作成日**: 2025-12-05
**ステータス**: 実装準備完了
