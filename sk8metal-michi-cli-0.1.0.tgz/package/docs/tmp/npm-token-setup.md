# NPM_TOKEN設定ガイド

このガイドでは、GitHub ActionsからNPMパッケージを自動公開するためのNPM_TOKEN設定手順を説明します。

## 概要

NPM_TOKENは、GitHub Actionsのリリースワークフロー（`.github/workflows/release.yml`）で使用される認証トークンです。
`v*`タグが作成された際に、自動的にNPMパッケージを公開するために必要です。

## 前提条件

- NPMアカウントを持っていること
- 公開するパッケージの所有者権限があること
- GitHubリポジトリへの管理者権限があること

## 手順

### Step 1: NPM Automation Tokenの生成

1. **NPM公式サイトにログイン**
   - https://www.npmjs.com/ にアクセス
   - ログインする

2. **Access Tokensページに移動**
   - 右上のプロフィールアイコンをクリック
   - 「Access Tokens」を選択
   - または直接 https://www.npmjs.com/settings/[username]/tokens にアクセス

3. **Automation Tokenを作成**
   - 「Generate New Token」ボタンをクリック
   - 「Automation」を選択（推奨）
     - **理由**: Automation Tokenは2要素認証（2FA）が有効でも使用可能
     - 有効期限: 90日（自動更新可能）
     - 権限: パッケージの公開・更新のみ
   - 「Generate Token」をクリック

4. **トークンをコピー**
   - ⚠️ **重要**: トークンは一度しか表示されません
   - 必ず安全な場所にコピーして保存してください
   - トークン形式: `npm_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

### Step 2: GitHub Secretsに追加

1. **GitHubリポジトリのSettingsに移動**
   - リポジトリページで「Settings」タブをクリック
   - 左メニューから「Secrets and variables」→「Actions」を選択

2. **New repository secretを作成**
   - 「New repository secret」ボタンをクリック
   - **Name**: `NPM_TOKEN`（大文字小文字を正確に）
   - **Secret**: Step 1でコピーしたNPM Automation Tokenを貼り付け
   - 「Add secret」をクリック

3. **確認**
   - Secrets一覧に`NPM_TOKEN`が表示されることを確認
   - ⚠️ トークンの値は表示されません（セキュリティのため）

### Step 3: 動作確認（オプション）

リリースワークフローが正しく動作するか確認するには、テストタグを作成します：

```bash
# 作業ディレクトリに移動
cd /Users/arigatatsuya/Work/git/michi

# 現在の状態を確認
jj status

# テスト用のタグを作成（実際には公開しない）
git tag v0.0.3-test

# タグを削除（テスト後）
git tag -d v0.0.3-test
```

**注意**: 実際のリリースを行う場合は、以下の手順で進めてください。

## 実際のリリース手順

### 1. バージョン番号の決定

`package.json`の`version`フィールドを確認・更新：

```json
{
  "version": "0.0.3"
}
```

### 2. CHANGELOGの更新

`CHANGELOG.md`にリリースノートを追加：

```markdown
## [0.0.3] - 2025-01-XX

### Added
- CI/CDパイプラインの整備
- テストカバレッジレポートの自動生成
```

### 3. コミット・プッシュ

```bash
# 変更をコミット
jj commit -m "chore: bump version to 0.0.3"

# プッシュ
jj git push
```

### 4. タグ作成・プッシュ

```bash
# タグを作成
git tag v0.0.3

# タグをプッシュ（これでリリースワークフローがトリガーされる）
git push origin v0.0.3
```

### 5. リリースワークフローの確認

1. GitHubリポジトリの「Actions」タブを確認
2. 「Release」ワークフローが実行されていることを確認
3. 各ステップが成功することを確認：
   - ✅ Checkout code
   - ✅ Setup Node.js
   - ✅ Install dependencies
   - ✅ Run tests
   - ✅ Run lint
   - ✅ Run type check
   - ✅ Build
   - ✅ Publish to NPM
   - ✅ Create GitHub Release

### 6. NPMパッケージの確認

- https://www.npmjs.com/package/@sk8metal/michi-cli にアクセス
- 新しいバージョンが公開されていることを確認

## トラブルシューティング

### エラー: `npm ERR! code E401`

**原因**: NPM_TOKENが無効または期限切れ

**解決方法**:
1. NPM Access Tokensページでトークンの有効期限を確認
2. 期限切れの場合は新しいトークンを生成
3. GitHub Secretsの`NPM_TOKEN`を更新

### エラー: `npm ERR! code E403`

**原因**: パッケージの公開権限がない

**解決方法**:
1. NPMアカウントでパッケージの所有者権限を確認
2. 必要に応じて、パッケージ所有者に追加してもらう
3. または、新しいパッケージ名で公開する

### エラー: `npm ERR! code E409`

**原因**: 同じバージョンが既に公開されている

**解決方法**:
1. `package.json`の`version`を更新
2. 新しいタグを作成して再実行

### リリースワークフローが実行されない

**原因**: タグのプッシュが正しく行われていない

**解決方法**:
1. タグがリモートに存在するか確認: `git ls-remote --tags origin`
2. タグの形式が`v*`であることを確認（例: `v0.0.3`）
3. タグを再プッシュ: `git push origin v0.0.3`

### GitHub Releaseが作成されない

**原因**: `GITHUB_TOKEN`の権限不足

**解決方法**:
1. `.github/workflows/release.yml`の`permissions`セクションを確認
2. `contents: write`が設定されていることを確認
3. リポジトリのSettings > Actions > General > Workflow permissionsで「Read and write permissions」が有効になっていることを確認

## セキュリティのベストプラクティス

### 1. Automation Tokenの使用

- **推奨**: Automation Tokenを使用（2FA有効でも使用可能）
- **非推奨**: Classic Token（2FA有効時は使用不可）

### 2. トークンの有効期限

- Automation Tokenのデフォルト有効期限は90日
- 期限切れ前に更新することを推奨
- または、自動更新を有効にする

### 3. 最小権限の原則

- Automation Tokenはパッケージ公開に必要な最小限の権限のみ
- 不要になったトークンは削除する

### 4. トークンの管理

- トークンはGitHub Secretsにのみ保存
- コードやコミットメッセージに含めない
- 共有しない

## 参考リンク

- [NPM Access Tokens公式ドキュメント](https://docs.npmjs.com/about-access-tokens)
- [GitHub Secrets公式ドキュメント](https://docs.github.com/ja/actions/security-guides/encrypted-secrets)
- [GitHub Actions公式ドキュメント](https://docs.github.com/ja/actions)

## 次のステップ

NPM_TOKEN設定完了後、以下の作業を進めることができます：

1. **semantic-release導入**（オプション）
   - CHANGELOGの自動生成
   - バージョン番号の自動更新
   - セマンティックバージョニングの自動化

2. **リリース前チェックリストの作成**
   - リリース前に確認すべき項目のリスト化
   - 自動チェックの追加

3. **リリースノートテンプレートの作成**
   - GitHub Releaseのテンプレート作成
   - 変更内容の自動分類

詳細は [CI/CD整備計画](./cicd-plan.md) を参照してください。

